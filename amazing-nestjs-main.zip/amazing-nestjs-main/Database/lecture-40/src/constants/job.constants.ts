export enum JOB_TYPE {
  PART_TIME = "PART_TIME",
  FULL_TIME = "FULL_TIME",
}
