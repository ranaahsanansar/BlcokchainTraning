export class EnvConfig {}
