export class CreateUserDTO {
  name: string;
  age: number;
  id: number;
}
