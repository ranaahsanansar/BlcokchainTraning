export class User {
  name: string;
  age: number;
  id: number;
}
