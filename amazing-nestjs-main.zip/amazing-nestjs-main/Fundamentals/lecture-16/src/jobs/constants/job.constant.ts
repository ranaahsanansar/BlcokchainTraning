export enum JOB_STATUS {
  OPENED = "OPENED",
  CLOSED = "CLOSED",
}
