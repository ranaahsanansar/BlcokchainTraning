import { Controller } from "@nestjs/common";

@Controller("jobs")
export class JobsController {}
