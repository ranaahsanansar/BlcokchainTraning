import { Controller } from "@nestjs/common";

@Controller("office")
export class OfficeController {}
