import { Controller } from "@nestjs/common";

@Controller("accounts")
export class AccountsController {}
