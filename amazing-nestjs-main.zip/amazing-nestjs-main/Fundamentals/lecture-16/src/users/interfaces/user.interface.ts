export interface User {
  name: string;
  age: number;
  id: number;
}
