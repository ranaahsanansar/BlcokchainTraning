export enum StoreType {
  FILE = "FILE",
  MEMORY = "MEMORY",
}
