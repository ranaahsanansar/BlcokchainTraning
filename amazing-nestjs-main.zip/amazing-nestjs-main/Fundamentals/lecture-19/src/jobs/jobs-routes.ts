import { JobsModule } from "./jobs.module";

export const JOBS_ROUTES = [
  {
    path: "jobs",
    module: JobsModule,
  },
];
