export enum JobType {
  FULL_TIME = 1,
  PART_TIME,
}
